"use strict";
exports.__esModule = true;
var express = require("express");
var app = express();
app.get('/api/finance', function (req, res) {
    var result = finances;
    res.json(result);
});
app.get('/api/finance/:id', function (req, res) {
    res.json(finances.find(function (finance) { return finance.id == req.params.id; }));
});
var server = app.listen(8000, 'localhost', function () {
    console.log("The server has been started and the port number is 8000!");
});
var FinanceInfo = /** @class */ (function () {
    function FinanceInfo(id, available, maxi) {
        this.id = id;
        this.available = available;
        this.maxi = maxi;
    }
    return FinanceInfo;
}());
exports.FinanceInfo = FinanceInfo;
;
var finances = [
    new FinanceInfo(1, 35400.66, 144000.01),
    new FinanceInfo(2, 12500.66, 123070.02),
    new FinanceInfo(3, 3440.88, 94000.03),
    new FinanceInfo(4, 9873.88, 85644.04),
    new FinanceInfo(5, 7553.66, 15476.85)
];
