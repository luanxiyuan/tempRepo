import { Component, OnInit } from '@angular/core';
import { FinanceService } from '../service/finance.service';
import { Router, ActivatedRoute ,Params} from '@angular/router';
import { Observable, empty } from 'rxjs';

@Component({
  selector: 'app-data-detail',
  templateUrl: './data-detail.component.html',
  styleUrls: ['./data-detail.component.css']
})
export class DataDetailComponent implements OnInit {

  cardId:number
  maxi: number;
  param: number;
  reiveId:number;
  resultData: any = {
    'id': '',
    'available': '',
    'maxi':'' 
  };
 
  sentData: any = {
    'available': '',
    'maxi':'',
    "inputVal": '' 
  };

    
  constructor(private financeService: FinanceService,
              private router: Router,
              private route: ActivatedRoute){}


  ngOnInit(){
   
    //Jump to different pages based on parameters
    this.route.params.subscribe((params: Params) => {
      if(params.id && params.id < 6){
        this.param = params.id;            
      }else if(params.id && params.id >=6){
        this.router.navigate(['**']);     
      }else {
        this.param = 1;
      }               
    });
      if(this.param<6){
        this.getServer();
      }
    
     
    
  }

   getServer(){
    this.financeService.getDatas(this.param)
    .subscribe(
      financeInfo => {
        console.log("financeInfo："+JSON.stringify(financeInfo));
        this.maxi = financeInfo.maxi;
        this.resultData['maxi'] = financeInfo.maxi;
        this.resultData['id'] = financeInfo.id;
        this.resultData['available'] = financeInfo.available; 
        this.cardId =  this.resultData['available'];
        console.log("this.cardId = "+  this.resultData['available']);  
      }
    );  
    
   }
 
  optionHandle(event){
    console.log("event:"+event);
    this.param =event;
    this.getServer();
    this.router.navigateByUrl('/dataDtail/'+this.param);
    
   }
    //click the submit button
  submitBtn(inputValue){
    if(((/^\d+(\.\d+)?$/)).test(inputValue) == true){
      if(inputValue<=this.resultData.maxi){
        this.sentData["available"] = this.resultData.available;
      this.sentData["maxi"] = this.resultData.maxi;
      this.sentData["inputVal"] = inputValue;
      localStorage.setItem('sentData', JSON.stringify(this.sentData));
      this.router.navigateByUrl("result"); 
      }else{
        alert("The input value should not exceed the maximum value!");
      }
      
    }else{
      alert("The value you entered is not valid. Please enter a number!");
    }
    
    
  }
    
}


