import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
import { Observable, from } from 'rxjs';
import {map} from 'rxjs/internal/operators/map';


@Injectable({
  providedIn: 'root'
})
export class FinanceService {
  
  constructor(private http: HttpClient) { }

  headers = new HttpHeaders({
    'Content-Type': 'application/json',
    'x-access-token': localStorage.getItem('token') ? localStorage.getItem('token') : ''
  });
 
  getDatas(id:number): Observable<any>{
     return this.http.get<any>('/api/finance/'+ id, {headers: this.headers}); 
  }
  getOption(): Observable<any>{
    return this.http.get('../../assets/selectOption.json'); 
 }
  


  
}

