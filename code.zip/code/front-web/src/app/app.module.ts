import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { DataDetailComponent } from './data-detail/data-detail.component';
import { ResultComponent } from './result/result.component';

import { NgxEchartsModule } from 'ngx-echarts';
import { EchartComponent } from './echart/echart.component';
import { FinanceService } from './service/finance.service';
import { HttpClientModule } from '@angular/common/http';
import { Code404Component } from './code404/code404.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatButtonModule} from '@angular/material/button';
import {MatSelectModule} from '@angular/material/select';
import {MatButtonToggleModule} from '@angular/material/button-toggle';




@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    DataDetailComponent,
    ResultComponent,
    EchartComponent,
    Code404Component,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgxEchartsModule,
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatSelectModule,
    MatButtonToggleModule
  
  ],
  exports: [MatButtonModule, MatSelectModule,MatButtonToggleModule],
  
  providers: [FinanceService],
  bootstrap: [AppComponent],
})
export class AppModule { }
